<?php

$conexion=mysqli_connect("localhost","root","","login")or die(
    "error de conexion");
?>